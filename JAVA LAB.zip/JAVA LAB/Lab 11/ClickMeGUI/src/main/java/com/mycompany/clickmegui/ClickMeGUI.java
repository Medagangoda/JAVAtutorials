package com.mycompany.clickmegui;
public class ClickMeGUI 
{
    public static void main(String[] args) 
    {
        Click ck= new Click();
        ck.show();
    }
}
