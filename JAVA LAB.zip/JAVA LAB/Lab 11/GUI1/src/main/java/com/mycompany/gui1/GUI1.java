package com.mycompany.gui1;
public class GUI1 
{
    public static void main(String[] args) 
    {
        ColorDemo c=new ColorDemo();
        c.show();
    }
}
