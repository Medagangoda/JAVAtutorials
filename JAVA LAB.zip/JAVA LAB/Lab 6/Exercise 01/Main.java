public class Main {
  public static void main(String[] args) {
    IntefaceImplemented impl = new IntefaceImplemented();
    impl.x = 10;
  }
}