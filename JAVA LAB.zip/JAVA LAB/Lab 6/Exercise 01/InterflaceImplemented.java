public class IntefaceImplemented implements MyFirstInterface {
  @Override
  public void display() {}
}