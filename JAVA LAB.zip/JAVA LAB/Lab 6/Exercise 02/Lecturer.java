public class Lecturer implements Speaker {
  @Override
  public void speak() {}
}