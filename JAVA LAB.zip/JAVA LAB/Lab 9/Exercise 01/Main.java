public class Main {
  public static void main(String[] args) {
    CylindricalContainer cylinder = new CylindricalContainer(5, 6);
    System.out.printf("The volume of the cylinder is : %.3f\n", cylinder.volume());
  }
}
