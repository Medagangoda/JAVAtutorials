/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practical4;

/**
 *
 * @author kavin
 */
public class subC extends SuperB{
    int x;
    public void triple() {
        x=x+3;
    } // override existing method
    public void quadruple() {
        x=x*4;
    } // new method

}
