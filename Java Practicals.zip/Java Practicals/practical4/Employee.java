/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practical4;

/**
 *
 * @author kavin
 */
public class Employee {
    private int empID; 
    private String empName; 
    private String empDesignation;
    
    public void setEmpID(int empID){
      this.empID=empID;
    }
    public int getEmpID(){
      return empID;
    }
    public void setEmpName(String empName){
      this.empName=empName;
    }
    public String getEmpName(){
       return empName;
     }
      public void setEmpDes(String empDesignation){
     this.empDesignation=empDesignation;
    }
    public String getEmpDes(){
       return empName;
     }

}
