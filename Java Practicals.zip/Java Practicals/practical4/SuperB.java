/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practical4;

/**
 *
 * @author kavin
 */
public class SuperB {
        int x;
    public void setIt(int n) {
        x=n;
    }
    public void increase(){ 
        x=x+1;
    }
    public void triple(){
        x=x*3;
    };
    public int returnIt(){
        return x;
    }

}
