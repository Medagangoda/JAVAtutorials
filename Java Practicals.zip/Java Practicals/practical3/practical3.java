/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practical3;

/**
 *
 * @author kavin
 */
public class practical3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Employee emp1=new Employee(2000);
        emp1.setName("Kavindu");
        emp1.setAge(23);
        emp1.setSalary(50000);
        emp1.displayData();
    }
    
}
