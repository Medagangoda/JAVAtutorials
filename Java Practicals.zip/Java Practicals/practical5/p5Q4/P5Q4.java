package com.mycompany.p5q4;
import java.lang.Math;

public class P5Q4 
{

    public static void main(String[] args)
    {
        Rectangle rectangle = new Rectangle("Rectangle", 10, 5);
        rectangle.display();

        Circle circle = new Circle("Circle", 5);
        circle.display();
    }
}
