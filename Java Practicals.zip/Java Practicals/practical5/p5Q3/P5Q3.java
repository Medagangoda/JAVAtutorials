package com.mycompany.p5q3;

public class P5Q3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
