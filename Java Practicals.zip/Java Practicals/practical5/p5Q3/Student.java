package com.mycompany.p5q3;

public class Student 
{
    final int marks =100;
    //marks=90
    //final value cannot be re assigned
    final void display()
    {
        System.out.println(marks);
    }
    
}
