package com.mycompany.p5q2;

public class P5Q2 {

    public static void main(String[] args)
    {
        Lecturer obj1=new Lecturer();
        obj1.speak();
        
        Politician obj2=new Politician();
        obj2.speak();
        
        Priest obj3=new Priest();
        obj3.speak();
    }
}
