package com.mycompany.p5q2;

public class Politician implements Speaker
{
        @Override
        public void speak()
        {
            System.out.println("As a politician, I stand up for your rights ");
        }
   
}
